package web.service.face;

import java.util.List;

import web.dto.QuizAnswer;
import web.dto.QuizQuestion;

public interface AdminStyleQuizService {
	
//	//퀴즈목록 출력
//	public List<QuizQuestion> selectList();
//	
//	//퀴즈질문 추가
//	public void quizInsert(QuizQuestion qq);
//	
//	//퀴즈질문 수정
//	public void quizUpdate(QuizQuestion qq);
//	
//	//퀴즈질문 삭제
//	public void quizDelete(QuizQuestion qq);
//	
//	//퀴즈답변항목 추가
//	public void quizAnswerInsert(QuizAnswer qa);
//	
//	//퀴즈답변항목 수정
//	public void quizAnswerUpdate(QuizAnswer qa);
//	
//	//퀴즈답변항목 삭제
//	public void quizAnswerDelete(QuizAnswer qa);
	
	
}
