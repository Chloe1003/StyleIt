package web.service.face;

import java.util.List;

import web.dto.Member;

public interface AdminUserService {

//	//회원관리 리스트
//	public List<Member> selectSerachList();
//	
//	//회원관리 수정
//	public void userUpdate(Member member);
//	
//	//회원관리 비활성화
//	public void userDisable(Member member);
}
