package web.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

@Controller
public class CollectionController {
	
	private static final Logger logger = LoggerFactory.getLogger(CollectionController.class);
	
	
	

}
